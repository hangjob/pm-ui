import Vue from 'vue'
import PmDocCard from './card';
import PmTop from './top';
import VcSnippet  from './vc-snippet';
Vue.component(PmDocCard.name, PmDocCard)
Vue.component(PmTop.name, PmTop)
Vue.component(VcSnippet.name, VcSnippet) // 代码片段
