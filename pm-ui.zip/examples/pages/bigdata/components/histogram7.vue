<template>
    <div class="">
        <div class="item-echats">
            <div ref="main1" style="width: 450px;height:400px;"></div>
        </div>
        <div class="item-echats">
            <div ref="main2" style="width: 450px;height:400px;"></div>
        </div>
        <div class="mask"></div>
    </div>
</template>
<script>
export default {
    name: 'histogram7',
    mounted () {
        // this.init1()
        // this.init2()
    },
    methods: {
        init1 () {
            // 运动心率
            const colorList = ['#2DD64F', '#ADFF2F', '#0783FF']
            let data = [{ name: '健康', value: 40 }, { name: '安全', value: 29 }, { name: '养老', value: 31 }]
            let option = {
                title: {
                    text: '机构类型占比',
                    left: 'center',
                    textStyle: {
                        color: '#fff',
                        fontSize: 24,
                    },
                    padding: [26, 0],
                },

                tooltip: {
                    show: false,
                    trigger: 'item',
                },
                series: [
                    {
                        type: 'pie',
                        // center:["50%","36%"],
                        radius: ['42%', '55%'],
                        clockwise: true,
                        avoidLabelOverlap: false,
                        itemStyle: {
                            normal: {
                                color: function (params) {
                                    return colorList[params.dataIndex]
                                },
                            },
                        },

                        label: {
                            show: true,
                            position: 'outside',
                            formatter: (params) => {
                                return '{txt|' + params.name + '}'
                            },
                            align: 'left',
                            rich: {
                                txt: {
                                    color: '#f0f',
                                    width: 10,
                                    height: 10,
                                    padding: 0,
                                    fontSize: 12,
                                },

                            },
                        },
                        labelLine: {
                            show: true,
                            length: 20,
                            length2: 30,
                            lineStyle: {
                                color: '#72B1DA',
                                width: 1,
                            },
                        },
                        data: data,
                    },
                ],
            }
            this.$echarts.init(this.$refs.main1).setOption(option)
        },
        init2 () {
            // 运动心率
            const colorList = ['#2DD64F', '#ADFF2F', '#0783FF']
            let data = [{ name: '健康', value: 40 }, { name: '安全', value: 29 }, { name: '养老', value: 31 }]
            let option = {
                title: {
                    text: '机构类型占比',
                    left: 'center',
                    textStyle: {
                        color: '#fff',
                        fontSize: 24,
                    },
                    padding: [26, 0],
                },

                tooltip: {
                    show: false,
                    trigger: 'item',
                },
                series: [
                    {
                        type: 'pie',
                        // center:["50%","36%"],
                        radius: ['42%', '55%'],
                        clockwise: true,
                        avoidLabelOverlap: false,
                        itemStyle: {
                            normal: {
                                color: function (params) {
                                    return colorList[params.dataIndex]
                                },
                            },
                        },

                        label: {
                            show: true,
                            position: 'outside',
                            formatter: (params) => {
                                return '{txt|' + params.name + '}'
                            },
                            align: 'left',
                            rich: {
                                txt: {
                                    color: '#f0f',
                                    width: 10,
                                    height: 10,
                                    padding: 0,
                                    fontSize: 12,
                                },

                            },
                        },
                        labelLine: {
                            show: true,
                            length: 20,
                            length2: 30,
                            lineStyle: {
                                color: '#72B1DA',
                                width: 1,
                            },
                        },
                        data: data,
                    },
                ],
            }
            this.$echarts.init(this.$refs.main2).setOption(option)
        },
    },
}
</script>
<style lang="less" scoped>
.item-echats {
    display: inline-block;
}

.mask {
    position: absolute;
    top: 0;
    left: 0;
    width: 240px;
    height: 120px;
    background: -webkit-gradient(linear, 0, 0, 0 bottom, form(#787878), to(#FFFFFF));
    -webkit-transform: skew(10deg, 10deg);
}

.mask:before {
    position: absolute;
    content: '';
    top: 0;
    width: 100px;
    height: 120px;
    background-color: #fff;
    left: -78px;
    -webkit-transform: skew(-20deg, 0deg);
}

</style>
