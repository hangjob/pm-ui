import Vue from 'vue'
import biddataCard from './biddataCard'
import histogram1 from './histogram1'
import histogram2 from './histogram2'
import histogram3 from './histogram3'
import histogram4 from './histogram4'
import histogram5 from './histogram5'
import histogram6 from './histogram6'
import histogram7 from './histogram7'

Vue.component(biddataCard.name, biddataCard)
Vue.component(histogram1.name, histogram1)
Vue.component(histogram2.name, histogram2)
Vue.component(histogram3.name, histogram3)
Vue.component(histogram4.name, histogram4)
Vue.component(histogram5.name, histogram5)
Vue.component(histogram6.name, histogram6)
Vue.component(histogram7.name, histogram7)
