import Vue from 'vue'
import * as g2 from '@antv/g2'

Vue.prototype.$g2 = g2;
