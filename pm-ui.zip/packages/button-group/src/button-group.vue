<template>
    <div class="pm-button-group">
        <slot></slot>
    </div>
</template>

<script>
export default {
    name: 'PmButtonGroup',
}
</script>
